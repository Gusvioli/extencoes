// Este arquivo é o script de conteúdo que é injetado nas páginas da web. 
// Ele pode manipular o DOM da página e interagir com o usuário.

document.addEventListener('DOMContentLoaded', () => {
    // Código adicional pode ser adicionado aqui se necessário
});